#!/bin/bash
# Лабораторная работа: Bash/Linux. Выполняются настоящие команды заданий 1-7 и итогового.
# Выполнил: Степанов Глеб Владиславович, группа 25о9-090207-ИС/3
# Запуск:  bash run_steps.sh  — после каждого задания скрипт сам снимает скриншот окна терминала в screenshots/.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="$HOME/practice_linux"

# не удаляем старую работу, а переименовываем
if [ -e "$WORK" ]; then mv "$WORK" "${WORK}_old_$(date +%H%M%S)"; fi

SHOTS="$HERE/screenshots"; mkdir -p "$SHOTS"; N=0
shot() {  # делает настоящий снимок активного окна терминала
  N=$((N+1)); f="$SHOTS/$(printf '%02d' $N)_$1.png"; sleep 1
  if   command -v gnome-screenshot >/dev/null; then gnome-screenshot -w -f "$f"
  elif command -v scrot >/dev/null;            then scrot -u "$f"
  elif command -v import >/dev/null;           then import -window "$(xdotool getactivewindow 2>/dev/null || echo root)" "$f"
  elif command -v spectacle >/dev/null;        then spectacle -a -b -n -o "$f"
  elif command -v grim >/dev/null;             then grim "$f"
  else echo "!!! Нет программы для скриншотов (gnome-screenshot/scrot/import). Сделайте снимок вручную (Print Screen)."; read -rp "Enter... " _; return; fi
  [ -s "$f" ] || { echo "!!! Снимок не создан. Сделайте скриншот вручную (Print Screen)."; read -rp "Enter... " _; }
}
CUR=""
step() {
  if [ -n "$CUR" ]; then shot "$CUR"; fi
  CUR="$2"; clear
  echo "================ $1 ================"
  echo "Студент: Степанов Г.В., группа 25о9-090207-ИС/3 | $(whoami)@$(hostname) | $(date '+%d.%m.%Y %H:%M:%S')"
  echo
}
run()  { echo "\$ $*"; eval "$@"; }


step "Задание 1. Основные команды" task1
cd "$HOME" || exit 1
mkdir practice_linux && cd practice_linux || exit 1
run pwd; run whoami; run ls; run "ls -l"; run "ls -a"; run date

step "Задание 2. Создание каталогов и файлов" task2
run "mkdir data scripts results"
run pwd; run "ls -l"
run "touch students.txt"
printf 'Иванов И.И. 2005 Москва 4.5\nПетров П.С. 2006 Казань 4.2\nСидорова А.В. 2005 Омск 4.8\nСмирнов Д.А. 2006 Томск 3.9\nКузнецова М.И. 2005 Самара 4.6\n' > students.txt
echo "(файл students.txt заполнен пятью строками, как при редактировании в nano)"
run "cat students.txt"
run "echo 'тестовая строка' > test.txt"; run "cat test.txt"
run "mv test.txt example.txt"; run "ls"

step "Задание 3. Обработка текстовых данных" task3
run "wc -l students.txt"
run 'grep "Иванов" students.txt'
run 'grep "Казань" students.txt'
run "sort students.txt"
run "sort students.txt > sorted_students.txt"
run "cat sorted_students.txt"
run "wc -l students.txt"; run "wc -l sorted_students.txt"

step "Задание 4. Переменные" task4
student="Иванов И.И."; year=2005; city="Москва"
run 'echo "$student"'; run 'echo "$year"'; run 'echo "$city"'
filename="students.txt"
run 'cat "$filename"'
count=$(wc -l < "$filename")
run 'echo "Количество записей: $count"'
name="Иванов И.И."; grade=4.5
run 'echo "Студент: $name; город: $city; средний балл: $grade"'
city="Казань"
run 'echo "Студент: $name; город: $city; средний балл: $grade"'

step "Задание 5. Условные конструкции" task5
for grade in 4 3; do
  echo "grade=$grade"
  if [ "$grade" -ge 4 ]; then echo "Условие выполнено"; else echo "Условие не выполнено"; fi
done
for f in students.txt missing.txt; do
  if [ -f "$f" ]; then echo "$f: Файл найден"; else echo "$f: Файл не найден"; fi
done
for count in 5 3 7; do
  if [ "$count" -ge 5 ]; then echo "count=$count: Записей достаточно"; else echo "count=$count: Необходимо добавить записи"; fi
done

step "Задание 6. Циклы" task6
echo "for 1..10:"
for i in 1 2 3 4 5 6 7 8 9 10; do echo "Запись № $i"; done
echo "while 1..7:"
i=1
while [ "$i" -le 7 ]; do echo "Номер: $i"; i=$((i + 1)); done
echo "Чтение students.txt циклом:"
while IFS= read -r line; do echo "$line"; done < students.txt

step "Задание 7. Параметры сценария" task7
cat > scripts/parameters.sh <<'EOS'
#!/bin/bash
echo "Имя сценария: $0"
echo "Фамилия и инициалы: $1"
echo "Город: $2"
echo "Год рождения: $3"
echo "Количество параметров: $#"
EOS
run "cat scripts/parameters.sh"
cd scripts
run 'bash parameters.sh "Иванов И.И." "Москва" 2005'
run 'bash parameters.sh "Петров П.С." "Казань" 2006'
cd ..

step "Итоговое задание. Обработка students.txt" final
cat > scripts/check_students.sh <<'EOS'
#!/bin/bash
file="${1:-students.txt}"
if [ -f "$file" ]; then
    cat "$file"
    count=$(wc -l < "$file")
    echo "Количество записей: $count"
    if [ "$count" -ge 5 ]; then echo "Записей достаточно"; else echo "Необходимо добавить записи"; fi
else
    echo "Ошибка: файл $file не найден"
fi
EOS
run "bash scripts/check_students.sh students.txt"
run "bash scripts/check_students.sh missing.txt"

step "Готово" list
echo "Структура:"; run "ls -lR"
shot "$CUR"; echo; echo "Скриншоты сохранены в: $SHOTS"
